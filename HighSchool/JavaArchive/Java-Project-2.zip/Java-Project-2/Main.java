import java.util.Scanner;

class Main {

public static void main(String[] args) {

Scanner input = new Scanner(System.in);

System.out.println("yogurt - $1.00, tomato - $0.50, lettuce - $.30, skittles - $0.75");
double ustop1=0;
double ustop2=0;
double ustop3=0;
double discount = 0;
double newtotal =0;
System.out.print("Choose a topping(1)");

String top1 = input.next();
if (top1.equals("tomato")){
  ustop1 = .5;
}else if (top1.equals("yogurt")){
  ustop1 = 1;
}else if (top1.equals("lettuce")){
  ustop1 = .3;
}else if (top1.equals("skittles")){
  ustop1 = .75;
  }
System.out.print("Choose a topping(2)");
  
String top2 = input.next();
if (top2.equals("tomato")){
  ustop2 = .5;
}else if (top2.equals("yogurt")){
  ustop2 = 1;
}else if (top2.equals("lettuce")){
  ustop2 = .3;
}else if (top2.equals("skittles")){
  ustop2 = .75;
  }
System.out.print("Choose a topping(3)");
  
String top3 = input.next();
if (top3.equals("tomato")){
  ustop3 = .5;
}else if (top3.equals("yogurt")){
  ustop3 = 1;
}else if (top3.equals("lettuce")){
  ustop3 = .3;
}else if (top3.equals("skittles")){
  ustop3 = .75;
}
double total = ustop1+ustop2+ustop3; 
if (total >= 1){
  discount = Math.round((total*0.1) * 100.0) / 100.0;
  newtotal = Math.round((total-discount) * 100.0) / 100.0;;
}
System.out.printf("Toppings cost: $"+total+"%n");
System.out.printf("Discount: $"+discount+"%n");
System.out.printf("New Total: $"+newtotal);
}

}