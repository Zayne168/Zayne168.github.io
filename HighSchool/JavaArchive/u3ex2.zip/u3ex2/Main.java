import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    System.out.print("Enter a number 100-999 ");
    int number = input.nextInt() ;
    for (int i = 13; i < number; i+=13) {
  System.out.println(i);
}
  }
}