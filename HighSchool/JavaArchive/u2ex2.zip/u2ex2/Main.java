import java.util.Scanner;
class Main {
public static void main(String[] args) {
Scanner input = new Scanner(System.in);
System.out.print("Enter the hour in military time (1-24): ");
int hour = input.nextInt() ;
 if (hour >18) {
System.out.println("Good afternoon");
}
else if (hour<6) {
System.out.println("Good morning");
}
else if (18>hour) {
System.out.println("Good evening");
}
else {
System.out.println("Good day");
}
}
} 