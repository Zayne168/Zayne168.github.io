import java.util.Scanner;
class Main {
public static void main(String[] args) {
Scanner input = new Scanner(System.in);
boolean canVote = true;
int tRue = 3;
int fAlse = 4;
if(tRue==fAlse){System.out.println("true");} else{System.out.println("False");}
if(tRue>fAlse){
System.out.println(tRue+" is bigger");}
else{
System.out.println(fAlse+" is bigger");}
int n1=200;
int n2=300;
int n3=201;
  if(n2<n3&&n3<n1||n1<n3&&n3<n2){
System.out.println(n3+" is in middle");}
else if(n3<n1&&n1<n2||n2<n1&&n1<n3){
System.out.println(n1+" is in middle");}
else {
System.out.println(n2+" is in middle");}
  
System.out.print("Please make a selection: ");
int selection = input.nextInt();
switch(selection) {
  case 1:
    System.out.println("Color is yellow");
    break;
  case 2:
    System.out.println("Color is blue");
    break;
  case 3:
    System.out.print("Color is red");
    break;
  default:
System.out.println("Invalid Selection");}
  }
}
