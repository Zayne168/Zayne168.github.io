import java.util.Scanner;

class Main {
public static void main(String[] args) {
Scanner input = new Scanner(System.in);

System.out.println("Name");
String name = input.next();

System.out.println("First Initial");
String initial1 = input.next();
  
System.out.println("Last Initial");
String initial2 = input.next();

String initials = initial1+"." + initial2+".";
System.out.println("number:");
double n1 = input.nextDouble();

System.out.println("number 2:");
double n2 = input.nextDouble();

double plus = n1+n2;
double subtr =n1-n2;
double multip = n1*n2;
double divid =n1/n2;

System.out.println(name+" "+initials);
System.out.printf(n1+"+"+n2+"="+plus+"%n");
System.out.printf(n1+"-"+n2+"="+subtr+"%n");
System.out.printf(n1+"*"+n2+"="+multip+"%n");
System.out.printf(n1+"/"+n2+"="+divid+"%n");
}}