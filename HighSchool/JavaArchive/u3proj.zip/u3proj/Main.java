import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    System.out.println("Have a number in mind  (1-1000)!");
    System.out.println("Please use Capitals when using H,L, and G");
    System.out.println("Higher[H]");
    System.out.println("Lower[L]");
    System.out.println("Correct[G]");
    System.out.println("Press anything to continue");
    scanner.nextLine();
    double guess = 500;
    double min = 0;
    double max = 1000;
    char w ='w';
    char H ='H';
    char L ='L';
    char G ='G';
    while (w != 'G'){
      System.out.println("Is your Number: "+guess);
      w=scanner.next().charAt(0);
      if (w != H && w != G) {//Lower
        max=guess;
        guess=((max-min)/2)+min;
        guess=Math.round(guess);
      }else if (w != L && w != G){//Higher
        min=guess;
        guess=((max-min)/2)+min;
        guess=Math.round(guess);
      }}
    scanner.close();//break while loop=correct
    for (int i = 0; i <= guess; i++) {
      System.out.println(i+" Hip-hip-hooray!");
      }
    }
  }