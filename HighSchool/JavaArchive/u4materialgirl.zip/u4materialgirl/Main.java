class Main {
  public static void main(String[] args) {
    String[] cars = {"Volvo", "Chevrolet", "Ford", "Mazda"};
    System.out.println(cars[2]);
    System.out.println(cars.length);
    for (int i = 0; i < cars.length; i++) {
      System.out.println(cars[i]);}
    String[] othecars = {"BMW", "Mclaren", "Chrysler-Buick", "Aston Martin"};
    String[][] myCars = { cars, othecars };
    for (int i = 0; i < cars.length; ++i) {
      for(int j = 0; j < othecars.length; ++j) {
        System.out.println(myCars[i][j]);
      }
    }
  }//I get an error at the end and I do not know why, but the code works and answers the questions so I will pretend I did not see it for now.
}