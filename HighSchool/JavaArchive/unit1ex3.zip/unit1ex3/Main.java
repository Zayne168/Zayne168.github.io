import java.util.Scanner;
import java.util.*;
class Main {
 public static void main(String[] args) { 

   
  Scanner input = new Scanner(System.in);
  System.out.println("length: ");
  double length = input.nextDouble();
  System.out.println("width: ");
  double width = input.nextDouble();
  System.out.print("cost per square foot of tile: $");
  double cost = input.nextDouble();
  
  double footage = length*width;
  double total = cost*footage;
  System.out.printf("Square Footage: "+footage+"%n");
  System.out.printf("Total Cost: $"+total);
 }
}