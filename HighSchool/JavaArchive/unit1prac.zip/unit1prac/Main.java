import java.util.Scanner;
import java.util.*;
class Main {
 public static void main(String[] args) { 
  String name = "Zayne";
  int age = 17;
  char myCharacter = 'z';
  double interestRate = 0.12;
  System.out.println(name);
  System.out.println(age);
  System.out.println(myCharacter);
  System.out.println(interestRate);
  Scanner userInp = new Scanner(System.in);
  System.out.println("Enter username");
  String theName = userInp.nextLine();
  System.out.println("Username is: " + theName);
  Scanner theAge = new Scanner(System.in);
  System.out.println("Enter age");
  String theOut = theAge.nextLine();
  System.out.println("Age is: " + theOut);
  int blinks = 200;
  int min = 7;
  double blinksPerMinute = blinks/min;
  System.out.println(blinksPerMinute);


   
  Scanner baLance = new Scanner(System.in);
  System.out.print("$: ");
  double account;
  account = baLance.nextDouble();
  System.out.printf("$ %.2f",account);
 }
}
